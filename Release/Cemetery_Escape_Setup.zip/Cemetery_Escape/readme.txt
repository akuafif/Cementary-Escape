Run setup.exe to install and play

cheats
------
ctrl-f -> fog of war
ctrl-g -> godmode
ctrl-c -> skip level